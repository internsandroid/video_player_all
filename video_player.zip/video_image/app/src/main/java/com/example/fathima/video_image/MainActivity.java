package com.example.fathima.video_image;

import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    VideoView video;
    //static final String video_sample="one_day";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        video=(VideoView)findViewById(R.id.videoView2);
        MediaController mc=new MediaController(this);
        video.setMediaController(mc);
        Uri uri=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.one);
        video.setVideoURI(uri);
        //video.requestFocus();

        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mp.setLooping(true);
                video.start();
            }
        });
    }
}
