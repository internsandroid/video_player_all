package com.example.lenovo.video;

import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    VideoView v1;
    MediaController mc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        v1=(VideoView)findViewById(R.id.videoView);
        String path="android.resource://"+getPackageName()+"/"+R.raw.vid;
        mc=new MediaController(this);
        mc.setAnchorView(v1);
        mc.setMediaPlayer(v1);
        Uri uri=Uri.parse(path);
        v1.setMediaController(mc);
        v1.setVideoURI(uri);
        v1.start();
    }
}
