package com.example.admin.playing_video;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.net.Uri;
import android.widget.VideoView;
import android.widget.MediaController;

public class MainActivity extends AppCompatActivity {

    MediaController media_control;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        VideoView v1;
        v1=(VideoView)findViewById(R.id.video);
        Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.video_file);


                media_control = new MediaController(this);
                v1.setMediaController(media_control);

                v1.setVideoURI(uri);
                v1.start();

        }

    }

