package com.example.user.videoplayer;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;
import android.widget.MediaController;


public class MainActivity extends AppCompatActivity {
VideoView vv;


   MediaController media_control;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vv = (VideoView) findViewById(R.id.videoView);
        Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.girl);
        media_control = new MediaController(this);
        vv.setMediaController(media_control);
        vv.setVideoURI(uri);
        vv.start();

    }
}
